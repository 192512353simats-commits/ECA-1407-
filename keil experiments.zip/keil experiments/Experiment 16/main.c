//EMBEDDED SYSTEM-ECA1407
//NAME-CHAITANYA THAMBA
//REG_NO-192512353
#include <reg51.h>
#include <stdio.h>
void serial_ISR(void) interrupt 4
{
    char ch;

    if(RI)
    {
        RI = 0;
        ch = SBUF;

        printf("\n>>> INTERRUPT RECEIVED: ");
        printf("%c\n", ch);
    }
}

void delay(void)
{
    unsigned int i;
    for(i = 0; i < 50000; i++);
}

void main(void)
{
D    SCON = 0x50;
    TMOD = 0x20;
    TH1 = 0xFD;
    TR1 = 1;

    IE = 0x90;   // EA=1, ES=1
    TI = 1;

    while(1)
    {
        printf("Hello World\n");
        delay();
    }
}
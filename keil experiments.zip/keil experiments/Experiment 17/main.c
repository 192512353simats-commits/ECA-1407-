//EMBEDDED SYSTEM-ECA1407
//NAME- CHAITANYA THAMBA
//REG_NO-192512353
#include <reg51.h>
void serial_ISR(void) interrupt 4
{
    if(RI)
    {
        P1 = SBUF;
        RI = 0;
    }
}

void main()
{
    TMOD = 0x20;
    TH1  = 0xFD;
    SCON = 0x50;
    TR1  = 1;
    ES   = 1;
    EA   = 1;

    while(1);
}
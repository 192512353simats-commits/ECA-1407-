//EMBEDDED SYSTEM-ECA1407
//NAME- CHAITANYA THAMBA
//REG_NO-192512353
#include <reg51.h>
void main(void)
{
    unsigned int i;
    unsigned int array[5] = {0x1111, 0x4444, 0x8888, 0xABCD, 0x2222};
    unsigned long sum = 0;

    for(i = 0; i < 5; i++)
    {
        sum = sum + array[i];
    }

    P0 = (unsigned char)(sum & 0xFF);
    P1 = (unsigned char)((sum >> 8) & 0xFF);
    P2 = (unsigned char)((sum >> 16) & 0xFF);

    while(1);
}